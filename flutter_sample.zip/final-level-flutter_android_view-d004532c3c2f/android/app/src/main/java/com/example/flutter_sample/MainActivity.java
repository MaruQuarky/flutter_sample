package com.example.flutter_sample;

import androidx.annotation.NonNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.EventChannel;
import org.jetbrains.annotations.NotNull;

public class MainActivity extends FlutterActivity {
	@Override
	public void configureFlutterEngine(@NonNull @NotNull FlutterEngine flutterEngine) {
		super.configureFlutterEngine(flutterEngine);

		new EventChannel(flutterEngine.getDartExecutor(), "com.finallevel/mediation_ads/bannerView").setStreamHandler(new EventChannel.StreamHandler() {
			@Override
			public void onListen(Object arguments, EventChannel.EventSink events) {
			}

			@Override
			public void onCancel(Object arguments) {
			}
		});

		flutterEngine.getPlatformViewsController().getRegistry().registerViewFactory("BannerView", new BannerViewFactory());
	}
}
