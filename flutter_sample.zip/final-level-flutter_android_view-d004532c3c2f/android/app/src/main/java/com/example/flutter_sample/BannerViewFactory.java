package com.example.flutter_sample;

import android.content.Context;
import io.flutter.plugin.common.StandardMessageCodec;
import io.flutter.plugin.platform.PlatformView;
import io.flutter.plugin.platform.PlatformViewFactory;
import org.jetbrains.annotations.NotNull;

public class BannerViewFactory extends PlatformViewFactory {
	public BannerViewFactory() {
		super(StandardMessageCodec.INSTANCE);
	}

	@Override
	@NotNull
	public PlatformView create(Context context, int viewId, Object args) {
		final String[] order = {};

		return new BannerView(context, viewId, order, this);
	}

}
