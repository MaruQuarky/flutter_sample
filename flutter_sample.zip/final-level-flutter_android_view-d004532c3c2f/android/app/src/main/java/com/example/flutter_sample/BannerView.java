package com.example.flutter_sample;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import androidx.annotation.NonNull;
import io.flutter.plugin.platform.PlatformView;

public class BannerView implements PlatformView {
	private final FrameLayout _container;

	public BannerView(@NonNull final Context context, int viewId, @NonNull String[] adsOrder, BannerViewFactory factory) {
		_container = new FrameLayout(context);
		_container.setBackgroundResource(android.R.color.holo_blue_light);

		final FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(
				FrameLayout.LayoutParams.WRAP_CONTENT,
				FrameLayout.LayoutParams.WRAP_CONTENT,
				Gravity.CENTER
		);
		final ProgressBar progress = new ProgressBar(context);
		progress.setBackgroundResource(android.R.color.holo_orange_light);
		_container.addView(progress, params);
	}

	@Override
	public View getView() {
		return _container;
	}

	@Override
	public void dispose() {
	}

}
