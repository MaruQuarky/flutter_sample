import "dart:async";
import "dart:io";

import "package:flutter/foundation.dart";
import "package:flutter/rendering.dart";
import "package:flutter/services.dart";
import "package:flutter/widgets.dart";

class BannerView extends StatefulWidget {
  final String order;
  final void Function(double? width, double? height) onResize;

  const BannerView({required this.onResize, required this.order, Key? key}) : super(key: key);

  @override
  BannerViewState createState() => BannerViewState();
}

class BannerViewState extends State<BannerView> {
  static const String _viewType = "BannerView";
  static final _viewStream = const EventChannel("com.finallevel/mediation_ads/bannerView").receiveBroadcastStream();

  StreamSubscription? _subscription;

  @override
  void dispose() {
    _subscription?.cancel();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (Platform.isAndroid) {
      return _buildAndroid(context);
    } else if (Platform.isIOS) {
      return _buildIos(context);
    }

    throw UnimplementedError();
  }

  Widget _buildAndroid(BuildContext context) {
    return PlatformViewLink(
      viewType: _viewType,
      onCreatePlatformView: (params) {
        _log("PlatformViewLink.onCreatePlatformView: ${params.id} ${params.viewType}");

        _subscription?.cancel();
        _subscription = _viewStream.where(_filterEvents(params.id)).listen(
              _onData,
              onError: _onError,
              onDone: () => _log("EventChannel.onDone"),
              cancelOnError: true,
            );

        return PlatformViewsService.initSurfaceAndroidView(
          id: params.id,
          layoutDirection: Directionality.of(context),
          viewType: _viewType,
          creationParams: <String, String>{
            "ADS_ORDER": widget.order,
          },
          creationParamsCodec: const StandardMessageCodec(),
        )
          ..addOnPlatformViewCreatedListener(params.onPlatformViewCreated)
          ..create();
      },
      surfaceFactory: (context, controller) {
        _log("PlatformViewLink.surfaceFactory: ${controller.viewId}");

        return AndroidViewSurface(
          controller: controller as AndroidViewController,
          hitTestBehavior: PlatformViewHitTestBehavior.opaque,
          gestureRecognizers: const {},
        );
      },
    );
  }

  Widget _buildIos(BuildContext context) {
    return UiKitView(
      viewType: _viewType,
      onPlatformViewCreated: (id) {
        _log("UiKitView.onCreatePlatformView: $id $_viewType");

        _subscription?.cancel();
        _subscription = _viewStream.where(_filterEvents(id)).listen(
              _onData,
              onError: _onError,
              onDone: () => _log("EventChannel.onDone"),
              cancelOnError: true,
            );
      },
      layoutDirection: Directionality.of(context),
      creationParams: <String, String>{
        "ADS_ORDER": widget.order,
      },
      creationParamsCodec: const StandardMessageCodec(),
    );
  }

  static bool Function(dynamic event) _filterEvents(int viewId) {
    return (dynamic event) => (event is Map && event["viewId"] == viewId);
  }

  void _onData(dynamic event) {
    _log("EventChannel.onData: $event");

    if (event is Map) {
      final width = event["width"] as int;
      final height = event["height"] as int;

      widget.onResize(
        (width >= 0 ? width.toDouble() : null),
        (height >= 0 ? height.toDouble() : null),
      );
    }
  }

  void _onError(dynamic error, dynamic stack) {
    _log("EventChannel.onError: $error $stack");

    widget.onResize(0, 0);
  }
}

void _log(Object? object) {
  if (kDebugMode) {
    print("MediationAds: $object");
  }
}
